import React from 'react'
import IconoOnline from './IconoOnline'

export default function Avatar({ user }){
  console.log(`Avatar render - id:${user.id} (NO-OPT)`)
  return (
    <div className="avatar">
      <img src={user.avatar} alt={user.name} width="56" height="56" />
      <div className="avatar-info">
        <strong>{user.name}</strong>
        <IconoOnline isOnline={user.isOnline} userId={user.id} />
      </div>
    </div>
  )
}
