import React, { useState } from 'react'
import ListaIntermedia from './ListaIntermedia'

function generarUsuarios() {
  const users = Array.from({ length: 500 }, (_, i) => {
    const id = i + 1
    return {
      id,
      name: `Usuario ${id}`,
      email: `user${id}@ejemplo.com`,
      avatar: `https://i.pravatar.cc/150?img=${(i + 1) % 70 + 1}`,
      isOnline: Math.random() > 0.5
    }
  })
  return users
}

export default function ContadorPadre(){
  console.log('ContadorPadre render (NO-OPT)')
  const [count, setCount] = useState(0)

  const users = generarUsuarios()

  return (
    <div className="container">
      <h1>ContadorPadre (NO optimizado)</h1>
      <p>Contador local: {count}</p>
      <button onClick={() => setCount(c => c + 1)}>+1 local</button>

      <ListaIntermedia users={users} />
    </div>
  )
}
