import React from 'react'

export default function PuntitoVerde({ isOnline, userId }){
  console.log(`PuntitoVerde render - id:${userId} - isOnline:${isOnline} (NO-OPT)`)
  const style = {
    width:12,
    height:12,
    borderRadius:'50%',
    backgroundColor: isOnline ? 'green' : 'red',
    display:'inline-block'
  }
  return <div style={style} aria-hidden="true" />
}
