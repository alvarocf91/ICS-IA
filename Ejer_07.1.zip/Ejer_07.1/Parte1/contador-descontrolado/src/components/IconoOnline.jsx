import React from 'react'
import PuntitoVerde from './PuntitoVerde'

export default function IconoOnline({ isOnline, userId }){
  console.log(`IconoOnline render - id:${userId} (NO-OPT)`)
  return (
    <div className="icono-online">
      <span>{isOnline ? 'En línea' : 'Desconectado'}</span>
      <PuntitoVerde isOnline={isOnline} userId={userId} />
    </div>
  )
}
