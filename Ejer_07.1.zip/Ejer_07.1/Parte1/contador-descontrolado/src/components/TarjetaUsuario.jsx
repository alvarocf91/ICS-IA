import React from 'react'
import Avatar from './Avatar'

export default function TarjetaUsuario({ user }){
  console.log(`TarjetaUsuario render - id:${user.id} (NO-OPT)`)
  return (
    <div className="card">
      <Avatar user={user} />
      <div>
        <h3>{user.name}</h3>
        <p>{user.email}</p>
      </div>
    </div>
  )
}
