import React from 'react'
import ContadorPadre from './components/ContadorPadre'

export default function App(){
  return (
    <div className="app">
      <ContadorPadre />
    </div>
  )
}
